sub init()
    m.top.functionName = "loadMenu"
end sub

sub loadMenu()
    port = CreateObject("roMessagePort")
    request = CreateObject("roUrlTransfer")
    request.SetMessagePort(port)
    request.SetCertificatesFile("common:/certs/ca-bundle.crt")
    request.InitClientCertificates()
    request.AddHeader("Accept", "application/json")
    request.AddHeader("Cache-Control", "no-cache")
    request.EnableEncodings(true)
    request.SetUrl("https://www.bustersmarkets.com/api/deli-menu")
    if request.AsyncGetToString()
        event = Wait(12000, port)
        if Type(event) = "roUrlEvent"
            if event.GetResponseCode() = 200
                data = ParseJson(event.GetString())
                if validMenu(data)
                    m.top.result = {ok: true, menu: data}
                    return
                end if
            end if
        else
            request.AsyncCancel()
        end if
    end if
    m.top.result = {ok: false}
end sub

function validMenu(data as dynamic) as boolean
    if Type(data) <> "roAssociativeArray" then return false
    if Type(data.categories) <> "roArray" then return false
    if Type(data.items) <> "roArray" then return false
    for each cat in data.categories
        if Type(cat) <> "roAssociativeArray" then return false
        if Type(cat.id) <> "roString" or Type(cat.name) <> "roString" then return false
        if not isNumber(cat.order) then return false
    end for
    for each item in data.items
        if Type(item) <> "roAssociativeArray" then return false
        if Type(item.categoryId) <> "roString" or Type(item.name) <> "roString" then return false
        if not isNumber(item.price) then return false
        if item.price < 0 then return false
        if not isNumber(item.order) then return false
    end for
    return true
end function

function isNumber(value as dynamic) as boolean
    kind = Type(value)
    return kind = "roInt" or kind = "roInteger" or kind = "Integer" or kind = "roFloat" or kind = "Float" or kind = "roDouble" or kind = "Double" or kind = "roLongInteger" or kind = "LongInteger"
end function
