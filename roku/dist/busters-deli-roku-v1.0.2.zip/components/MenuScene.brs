sub init()
    configureFonts()
    m.top.backgroundColor = "#be1830"
    m.top.backgroundUri = ""
    m.content = m.top.FindNode("menuContent")
    m.message = m.top.FindNode("message")
    m.status = m.top.FindNode("status")
    m.pageLabel = m.top.FindNode("pageLabel")
    m.pages = []
    m.page = 0
    m.loaded = false
    m.paused = false
    m.lastMenu = ""
    m.task = CreateObject("roSGNode", "MenuFeed")
    m.task.ObserveField("result", "menuReceived")
    m.refresh = m.top.FindNode("refreshTimer")
    m.refresh.ObserveField("fire", "refreshMenu")
    m.refresh.control = "start"
    m.rotate = m.top.FindNode("pageTimer")
    m.rotate.ObserveField("fire", "nextPage")
    m.rotate.control = "start"
    m.top.SetFocus(true)
    refreshMenu()
end sub

sub refreshMenu()
    if m.task.state <> "run" then m.task.control = "RUN"
end sub

sub menuReceived()
    result = m.task.result
    if not result.ok
        if m.loaded
            m.status.text = "Connection interrupted - showing last received menu; retrying..."
        else
            m.message.text = "Unable to load menu. Check the TV's internet connection. Retrying automatically..."
        end if
        return
    end if
    m.loaded = true
    m.status.text = "Ask your server about today's specials"
    encoded = FormatJson(result.menu)
    if encoded = m.lastMenu then return
    m.lastMenu = encoded
    m.pages = makePages(result.menu)
    if m.page >= m.pages.Count() then m.page = 0
    renderPage()
end sub

' Each column fits three rows. Larger categories continue on later columns/pages.
function makePages(menu as object) as object
    columns = []
    menu.categories.SortBy("order")
    menu.items.SortBy("order")
    for each cat in menu.categories
        rows = []
        for each item in menu.items
            if item.categoryId = cat.id then rows.Push(item)
        end for
        offset = 0
        while offset < rows.Count()
            chunk = []
            for index = offset to offset + 2
                if index < rows.Count() then chunk.Push(rows[index])
            end for
            heading = cat.name
            if offset > 0 then heading = heading + " (continued)"
            columns.Push({heading: heading, items: chunk})
            offset = offset + 3
        end while
    end for
    pages = []
    index = 0
    while index < columns.Count()
        page = [columns[index]]
        if index + 1 < columns.Count() then page.Push(columns[index + 1])
        pages.Push(page)
        index = index + 2
    end while
    return pages
end function

sub renderPage()
    m.content.RemoveChildrenIndex(m.content.GetChildCount(), 0)
    m.message.visible = m.pages.Count() = 0
    if m.pages.Count() = 0
        m.message.text = "Today's menu isn't available yet. Please ask at the deli counter."
        m.pageLabel.text = ""
        return
    end if
    columnIndex = 0
    for each column in m.pages[m.page]
        x = columnIndex * 896
        addLabel(m.content, column.heading, x, 0, 832, 76, 38, "#ffdc55", true)
        rowIndex = 0
        for each item in column.items
            y = 88 + rowIndex * 126
            color = "#fff5df"
            price = money(item.price)
            if item.soldOut = true
                color = "#ffe2ba"
                price = "Sold out"
            end if
            addLabel(m.content, item.name, x, y, 620, 76, 32, color, true)
            priceNode = addLabel(m.content, price, x + 628, y, 204, 48, 32, "#ffdc55", false)
            priceNode.horizAlign = "right"
            detail = ""
            if Type(item.description) = "roString" then detail = item.description
            if item.featured = true and item.soldOut <> true then detail = "Today's pick | " + detail
            addLabel(m.content, detail, x, y + 78, 832, 34, 23, "#ffe2ba", false)
            rowIndex = rowIndex + 1
        end for
        columnIndex = columnIndex + 1
    end for
    m.pageLabel.text = (m.page + 1).ToStr() + " / " + m.pages.Count().ToStr()
    if m.paused then m.pageLabel.text = m.pageLabel.text + "  |  Paused"
end sub

function addLabel(parent as object, text as string, x as integer, y as integer, width as integer, height as integer, size as integer, color as string, wrap as boolean) as object
    label = parent.CreateChild("Label")
    label.translation = [x, y]
    label.width = width
    label.height = height
    label.text = text
    label.color = color
    label.wrap = wrap
    label.maxLines = 2
    label.font = "font:MediumSystemFont"
    label.font.size = size
    return label
end function

function money(value as dynamic) as string
    cents = Int(value * 100 + 0.5)
    whole = Int(cents / 100)
    fraction = cents mod 100
    tail = fraction.ToStr()
    if fraction < 10 then tail = "0" + tail
    return "$" + whole.ToStr() + "." + tail
end function

sub nextPage()
    if m.pages.Count() < 2 then return
    m.page = (m.page + 1) mod m.pages.Count()
    renderPage()
end sub

function onKeyEvent(key as string, press as boolean) as boolean
    if not press then return false
    if key = "right" or key = "left"
        if m.pages.Count() > 0
            direction = 1
            if key = "left" then direction = -1
            m.page = (m.page + direction + m.pages.Count()) mod m.pages.Count()
            renderPage()
            m.rotate.control = "stop"
            if not m.paused then m.rotate.control = "start"
        end if
        return true
    else if key = "OK" or key = "play"
        m.paused = not m.paused
        m.rotate.control = "stop"
        if not m.paused then m.rotate.control = "start"
        renderPage()
        return true
    end if
    return false
end function

' Select built-in fonts before changing sizes; an empty Font URI cannot render text.
sub configureFonts()
    m.top.FindNode("staticText0").font.size = 76
    m.top.FindNode("staticText1").font.size = 42
    m.top.FindNode("message").font.size = 36
    m.top.FindNode("staticText3").font.size = 54
    m.top.FindNode("status").font.size = 24
    m.top.FindNode("pageLabel").font.size = 22
    m.top.FindNode("staticText6").font.size = 18
end sub
